<template>
  <router-link to="/"></router-link>
  <RouterView></RouterView>
</template>

<script>
export default {
    name: 'App',
}
</script>


<style>
html {
    height: 100%;
    width: 100%;
}

body {
    height: 100%;
    width: 100%;
    margin: 0;
}

#app {
    min-height: 100%;
    width: 100%;
    height: 100%;
}
</style>
